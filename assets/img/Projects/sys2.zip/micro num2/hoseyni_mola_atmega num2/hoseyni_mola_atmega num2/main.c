/*
 * digitalsystems2final_project_hoseyni_mola.c
 *
 * Created: 1/29/2022 4:14:47 PM
 * Author : mmd
 */ 

#define F_CPU 8000000UL
#define FOSC 16000000// Clock Speed
#define BAUD 9600
#define MYUBRR FOSC/16/BAUD-1

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <avr/delay.h>
#include <util/delay.h>

/*------LCD defines start-------*/
#define D4 eS_PORTC0
#define D5 eS_PORTC1
#define D6 eS_PORTC2
#define D7 eS_PORTC3
#define RS eS_PORTC4
#define EN eS_PORTC5
#include "lcd.h"
/*------LCD defines end--//-----*/

/*------general variables start-------*/
int general_flag=0;															//to change flow of main program
unsigned char data;
unsigned int  setpoint , ADC_value; 
unsigned char situation=0xff,situation_flag=100,compare_situation;
int duty=0;
/*------general variables end---------*/

/*------keypad variables start-------*/
int key_pad_array[2]={13,13};												//saves amount of key that is pressed
int key_pad_counter=0;														//count how many integer remain
int key_pad_value=00;														//final value to show on LCD and compare for PWM
/*------keypad variables end---------*/			

/*------functions start---------*/		
void USART_Init( unsigned int ubrr );
unsigned char USART_Receive( void );
void timer0_init(void);
/*------functions start---------*/		

int main(void)
{

	/*------LCD Text start---------*/
	char text_while_importing_data[16] = "enter setpoint"; 
	char number_while_importing_data[10] = {"0"};
	/*------LCD Text end---------*/
	DDRC=0xff;																	//set LCD pins out put
	Lcd4_Init();																//initialize LCD i 4bits mode
	USART_Init(MYUBRR);
	DDRB |= (1 << PB4);
    /* Replace with your application code */
	sei();
    while (1) 
    {	
	
		if(compare_situation != situation) Lcd4_Clear();
		if(situation == 1)														//0 is normal
		{
			duty = setpoint - ADC_value;
			if(duty < 0) duty = 0;
			timer0_init();
			Lcd4_Set_Cursor(1,1);	
			sprintf(number_while_importing_data,"%d",(int)setpoint);	
			Lcd4_Write_String(number_while_importing_data);	
			Lcd4_Set_Cursor(2,1);
			sprintf(number_while_importing_data,"%d",2*duty);
			Lcd4_Write_String(number_while_importing_data);
			_delay_ms(100);
		}
		else if(situation == 0)													//1 for while user inputing number
		{
			Lcd4_Set_Cursor(1,1);												//set LCD cursor to x=1,y=1;
			Lcd4_Write_String(text_while_importing_data);						//write text at top of LCD
			sprintf(number_while_importing_data,"%d",(int)setpoint);			//convert int to string
			Lcd4_Set_Cursor(2,1);												//set LCD cursor to x=1,y=2;
			Lcd4_Write_String("  ");											//clear second line of LCD
			Lcd4_Set_Cursor(2,1);												//set LCD cursor to x=1,y=2;
			Lcd4_Write_String(number_while_importing_data);						//write text at top of LCD
			_delay_ms(100);
		}					
	}
		
		
}



void USART_Init( unsigned int ubrr )
{
	/* Set baud rate */
	UBRR0H = (unsigned char)(ubrr>>8);
	UBRR0L = (unsigned char)ubrr;
	/* Enable receiver and transmitter */
	UCSR0B = (1<<RXEN)|(1<<RXCIE);
	/* Set frame format: 8data, 2stop bit */
	UCSR0C = (1<<USBS)|(3<<UCSZ0);
}

unsigned char USART_Receive( void )
{
	/* Wait for data to be received */
	while ( !(UCSR0A & (1<<RXC)) );
	/* Get and return received data from buffer */
	return UDR0;
}

ISR(USART0_RX_vect)
{
	data = UDR0;
	if(data == 0xff)
	{
		situation_flag = 1;
		
	}
	else if(situation_flag == 1)
	{
		situation = data;
		situation_flag = 0;
		
	}
 	else
 	{
 		if((data & 1))
 		{
	 		PORTC ^= 0x80;
	 		ADC_value=(data>>1);
 		}
 		else
 		{
	 		PORTC ^= 0x40;
	 		setpoint=(data>>1);
 		}		
				
 	}
	
}
void timer0_init(void)
{	TCNT0 = 0;
	OCR0 = 255*duty/50;
	TIMSK = 1<<TOIE0;
	TCCR0 = 0;
	TCCR0 |= (1 << WGM00) | (1 <<COM01) | (1 << CS01) | (1 << CS02);
}
ISR(TIMER0_OVF_vect)
{
	OCR0=127*duty/50;
}