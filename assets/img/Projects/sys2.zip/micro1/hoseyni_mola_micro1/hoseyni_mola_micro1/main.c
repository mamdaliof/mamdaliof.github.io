/*
 * digitalsystems2final_project_hoseyni_mola.c
 *
 * Created: 1/29/2022 4:14:47 PM
 * Author : mmd
 */ 
#define F_CPU 8000000UL
#define FOSC 16000000// Clock Speed
#define BAUD 9600
#define MYUBRR FOSC/16/BAUD-1

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>
#include <stdio.h>
#include <util/delay.h>
#include <math.h>
#include <avr/delay.h>

/*------general variables start-------*/
int general_flag=0;								//to change flow of main program
unsigned char set_point;
unsigned char ADC_value;
/*------general variables end---------*/

/*------keypad variables start-------*/
int key_pad_array[2]={13,13};					//saves amount of key that is pressed
int key_pad_counter=0;							//count how many integer remain
int key_pad_value=00;							//final value to show on LCD and compare for PWM
/*------keypad variables end---------*/

/*------functions start---------*/
void INT0_Init(void);
void read_keypad(void);
void arry2int(void);
void ADC0_init(void);
int  ADC0_Read(void);
void USART_Init( unsigned int ubrr );
void USART_Transmit( unsigned char data );
/*------functions end-----------*/
int main(void)
{
	sei();										//enable interrupt
	INT0_Init();								//initialize INT0
	ADC0_init();								//initialize ADC0
	DDRA=0x0f;									//set A0-A3 as output ans set A4-A7 as input
	DDRB=0xff;									//make LED pin out put
	PORTA=0xf0;									//pull-up A4-A7 and assign loW logic to A0-A3
	PORTD=1;									//pull-up D0 
	USART_Init(MYUBRR);							//initialize USART	
    /* Replace with your application code */

    while (1) 
    {	
		USART_Transmit(0xff);
		_delay_ms(50);
		if(general_flag) USART_Transmit(1);
		else 
		{USART_Transmit(0);
		PORTB ^= 8;
		}
		_delay_ms(50);
		ADC_value=(char)(ADC*50/1023);
		ADC_value=ADC_value<<1;
		USART_Transmit(ADC_value+1);		 //ADC=1
		arry2int();
		_delay_ms(50);
		if(key_pad_counter == 1) key_pad_value /= 10;
		set_point=(char)key_pad_value;		//setpoint=0
		USART_Transmit(set_point<<1);
		_delay_ms(50);		
    }

	
}
/*-----interrupt's settings start-------*/
void INT0_Init(void)
{
	EICRA=0;
	EICRA|=1<<(ISC01);							//set INT0 mode in falling edge
	EIMSK=1<<(INT0);
}
/*-----interrupt's settings end---------*/

/*-----read keypad start---------*/
void read_keypad(void)
{
	
	/*------function variables start-------*/
	int i ,j ;									//for nested loops
	int row_position,col_position;				//variable to indicate position of the key that is pressed
	int key[2] = {0,0};							//to calculate value of the key that is pressed
	/*------function variables end---------*/
	row_position = (~PINA & 0xf0);					//indicate row of the key that is pressed
	for (j=0 ; j<4 ; j++)						//count rows to find desired row
	{
		
		if(row_position == (1 << (j+4)))
		{
			key[0] = j;							//save position of row
			for (i=0 ; i<4 ; i++)
			{
				PORTA|=(1<<i);					//turn on every pin of columns to find desired column
				
				col_position = (~PINA & 0xf0);	//read rows
				if(col_position == 0)
				{
					key[1] = i;					//save position of column
					PORTA = 0xf0;
					if(4*key[0]+key[1] == 3)    //if user press divide key
					{
						general_flag = 0;			//set general flag to 0 and change flow of program
					//	Lcd4_Clear();
						key_pad_counter=0;		//assign 0 to key counter to prevent hazards 
						key_pad_array[0]=13;	//reset value of key pad
						key_pad_array[1]=13;
					}
					else if(general_flag == 0)
					{
						key_pad_counter++;		//count how many times user press keys
						if(key_pad_counter == 3)// is inserting integer done?
						{
							if (4*key[0]+key[1] == 12)			//it is done
							{
								general_flag = 1;						//set general flag to 1 and change flow of program
								key_pad_counter = 0;					//assign 0 to key counter to prevent hazards 
						//		Lcd4_Clear();							//clear LCD to rewrite new text
						//		Lcd4_Init();							//re initialize LCD
								break;
							}
							else				//user wanna reset value of inserted integer
							{
								key_pad_array[0] = 13;
								key_pad_array[1] = 13;
								key_pad_array[0] = 4*key[0]+key[1];
								key_pad_counter = 1;
								break;
							}
						}
						if(general_flag == 0) key_pad_array[key_pad_counter-1] = 4*key[0]+key[1];
					}
					
				}
				
			}
			PORTA=0xf0;
			break;
		}
	}
	
}
/*-----read keypad end-----------*/
/*-----INT0 subroutine start-------*/
ISR(INT0_vect)
{
	PORTB ^= 2;									//toggle LED
	read_keypad();								//read key pad value
	
}
/*-----INT0 subroutine end-------*/

/*-----extract value that user imported start-------*/
void arry2int(void)
{
	key_pad_value=0;
	int i ,temp;
	for (i=0;i<2;i++)
	{
		temp=0;
		switch(key_pad_array[i])
		{
			case 0:
			temp=7;
			break;
			
			case 1:
			temp=8;
			break;
			
			case 2:
			temp=9;
			break;
			
			case 4:
			temp=4;
			break;
			
			case 5:
			temp=5;
			break;
			
			case 6:
			temp=6;
			break;
			
			case 8:
			temp=1;
			break;
			
			case 9:
			temp=2;
			break;
			
			case 10:
			temp=3;
			break;
			
			
			case 13:
			temp=0;
			break;
			
		}
		switch(i)
		{
			case 0:
			key_pad_value+=temp*10;
			break;
			case 1:
			key_pad_value+=temp;
			break;
		}
	}

}
/*-----extract value that user imported end-------*/

/*-----ADC initialize start-------*/

void ADC0_init(void)
{
	ADMUX=0;
	ADMUX |= 1<<REFS0;							//determine ADC reference  
	ADCSRA = 0;									
	ADCSRA |= 1<<ADEN | 1<<ADSC | 1<<ADFR;		//enable ADC | start conversion | enable free running 
}

/*-----ADC initialize end---------*/

void USART_Init( unsigned int ubrr )
{
	/* Set baud rate */
	UBRR0H = (unsigned char)(ubrr>>8);
	UBRR0L = (unsigned char)ubrr;
	/* Enable receiver and transmitter */
	UCSR0B = (1<<RXEN)|(1<<TXEN);
	/* Set frame format: 8data, 2stop bit */
	UCSR0C = (1<<USBS)|(3<<UCSZ0);
}

void USART_Transmit( unsigned char data )
{
	/* Wait for empty transmit buffer */
	while ( !( UCSR0A & (1<<UDRE)) )
	;
	/* Put data into buffer, sends the data */
	UDR0 = data;
}

